// AImagic.js
// Model-driven parser → returns a normalized plan your UI can apply.

const MODEL_ENDPOINT = process.env.MODEL_ENDPOINT || "https://api.openai.com/v1/chat/completions"; // or your proxy
const MODEL_NAME = process.env.MODEL_NAME || "gpt-4o-mini"; // or your cheap parser model
const MODEL_API_KEY = process.env.MODEL_API_KEY || ""; // set this in env; do NOT hardcode

// ---- Public API used by TaskApp ----
export async function askAIToEdit({ threads, instruction }) {
  const prompt = buildPrompt(instruction);
  const rawText = await callModelJSON(prompt);

  const parsed = coercePlan(rawText);
  // Always return a stable shape
  return {
    threads: parsed.threads,
    logs: parsed.logs
  };
}

// ---- Prompt builder ----
function buildPrompt(input) {
  return {
    system: [
      "You convert messy human text into a structured plan for a to-do app.",
      "Rules:",
      "1) Return ONLY compact JSON. No prose. No markdown fences.",
      "2) Group related items under short parent 'threads' (e.g., 'Bathroom fix', 'GP / Health').",
      "3) Create short step titles. Remove filler like 'need to', 'please', 'add'.",
      "4) Nest clear substeps when there’s an obvious parent→child (e.g., Sink → Outflow).",
      "5) Ignore negations like 'don't add', 'ignore this'.",
      "6) Put non-actionable feelings/notes into logs: {category, text}. Categories may include mood, sleep, gym, general.",
      "7) No dates/times here. Just structure.",
      "8) Titles must be concise, Title Case.",
      "9) Output shape exactly:",
      `{"threads":[{"title":"...","steps":[{"title":"...","substeps":["..."]}]}],"logs":[{"category":"...","text":"..."}]}`,
      "10) Do not invent extra fields."
    ].join("\n"),
    user: [
      "Input:",
      String(input || "").trim()
    ].join("\n")
  };
}

// ---- Model call (OpenAI-compatible) ----
async function callModelJSON({ system, user }) {
  const body = {
    model: MODEL_NAME,
    messages: [
      { role: "system", content: system },
      { role: "user", content: user }
    ],
    temperature: 0.2,
    response_format: { type: "json_object" }
  };

  const res = await fetch(MODEL_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(MODEL_API_KEY ? { Authorization: `Bearer ${MODEL_API_KEY}` } : {})
    },
    body: JSON.stringify(body)
  });

  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`Model HTTP ${res.status}: ${t.slice(0, 200)}`);
  }

  const json = await res.json();
  // OpenAI-compatible shape
  const content =
    json?.choices?.[0]?.message?.content ??
    json?.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments ??
    "";

  return String(content || "");
}

// ---- Parsing / validation ----
function coercePlan(text) {
  let s = (text || "").trim();

  // Strip ```json fences if a model ignores response_format
  const fence = s.match(/```(?:json)?\s*([\s\S]+?)\s*```/i);
  if (fence) s = fence[1].trim();

  let obj;
  try { obj = JSON.parse(s); }
  catch { obj = {}; }

  const threads = Array.isArray(obj.threads) ? obj.threads : [];
  const logs = Array.isArray(obj.logs) ? obj.logs : [];

  // sanitize
  const cleanThreads = threads
    .map(t => ({
      title: asTitle(t?.title),
      steps: Array.isArray(t?.steps) ? t.steps.map(cleanStep).filter(Boolean) : []
    }))
    .filter(t => t.title && t.steps.length > 0);

  // de-dup thread titles
  const seenThreads = new Set();
  const dedupThreads = [];
  for (const t of cleanThreads) {
    const key = t.title.toLowerCase();
    if (seenThreads.has(key)) continue;
    seenThreads.add(key);
    dedupThreads.push(t);
  }

  const cleanLogs = logs
    .map(l => ({
      category: asWord(l?.category) || "general",
      text: asText(l?.text)
    }))
    .filter(l => l.text);

  return { threads: dedupThreads, logs: cleanLogs };
}

function cleanStep(s) {
  const title = asTitle(s?.title);
  if (!title) return null;
  const substeps = Array.isArray(s?.substeps) ? s.substeps.map(asTitle).filter(Boolean) : [];
  // de-dup substeps
  const seen = new Set();
  const dedup = [];
  for (const sub of substeps) {
    const k = sub.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    dedup.push(sub);
  }
  return { title, substeps: dedup };
}

function asTitle(v) {
  const t = asText(v)
    .replace(/^(add|please|need to|have to|must|should|remind me to|remember to)\s+/i, "")
    .trim();
  if (!t) return "";
  return t.replace(/\s+/g, " ")
    .toLowerCase()
    .replace(/\b\w/g, c => c.toUpperCase());
}
function asText(v){ return typeof v === "string" ? v.trim() : ""; }
function asWord(v){ return asText(v).toLowerCase().replace(/[^a-z/ ]+/g,"").slice(0,40); }
