import { useTaskStore } from '../store/useTaskStore';
import { tone } from './tone';
// Import the model-driven parser.  This function takes the user
// instruction and returns a structured plan with threads and logs.
import { askAIToEdit } from '../ai/AImagic';

/**
 * This function should call your LLM provider to generate a reply.
 * For now it returns a canned response.  Replace with your API
 * integration (e.g. fetch to OpenAI) and consider using tools or
 * function calling for structured actions.
 */
async function callLLM(messages) {
  // Example stub: simply echo the user's last message with a note.
  // In the future you can integrate a real chat model here to reply
  // to the user.  The AI editing logic happens separately via
  // askAIToEdit; this function is only responsible for generating
  // human‑readable chat responses.
  const userMsg = messages[messages.length - 1]?.content || '';
  return `I have noted your request: "${userMsg}".`;
}

/**
 * Primary entrypoint for handling chat messages.  Runs intent
 * detection against the user text, executes any relevant state
 * mutations (add thread/step, mark done, etc.), then calls the LLM
 * to formulate a reply.  Returns the assistant reply along with
 * a list of actions executed.
 */
export async function chatAndMaybeAct(userText) {
  const {
    threads,
    upsertThread,
    addStepTop,
    toggleStep,
    addLog,
    removeStep,
    elevateStepToThread,
    markFocus,
  } = useTaskStore.getState();
  const actions = [];
  const lower = userText.toLowerCase();

  // Simple pattern matching for basic edits (delete/promote/rename/focus
  // etc.) can be added here.  For now we retain support for a
  // handful of primitives: add thread, add step, and complete.
  const addThreadMatch = lower.match(/add\s+thread\s+(.+)/);
  if (addThreadMatch) {
    const title = addThreadMatch[1].trim();
    const id = upsertThread(title);
    actions.push(`added-thread:${id}:${title}`);
  }
  const addStepMatch = lower.match(/add\s+step\s+(.+)/);
  if (addStepMatch) {
    const title = addStepMatch[1].trim();
    const threadId = threads[0]?.id || upsertThread('General');
    const sid = addStepTop(threadId, title);
    actions.push(`added-step:${sid}:${title}`);
  }
  const markDoneMatch = lower.match(/mark\s+.*(done|complete)/);
  if (markDoneMatch) {
    const thread = threads[0];
    const step = thread?.steps.find((s) => !s.done);
    if (thread && step) {
      toggleStep(thread.id, step.id);
      actions.push(`toggled:${step.id}`);
    }
  }

  // If no basic actions were found, fall back to the model‑driven parser.
  // We call askAIToEdit to obtain a structured plan (threads and logs)
  // from the user's free text.  We then map that plan into the
  // application's task store by creating threads and steps.  Logs
  // categories are used verbatim for the log kind.
  if (actions.length === 0) {
    try {
      const plan = await askAIToEdit({ threads, instruction: userText });
      if (plan?.threads) {
        for (const t of plan.threads) {
          const newId = upsertThread(t.title);
          actions.push(`added-thread:${newId}:${t.title}`);
          if (Array.isArray(t.steps)) {
            for (const step of t.steps) {
              const sid = addStepTop(newId, step.title);
              actions.push(`added-step:${sid}:${step.title}`);
              // Create substeps as additional top‑level steps under the same thread
              if (Array.isArray(step.substeps)) {
                for (const sub of step.substeps) {
                  const subId = addStepTop(newId, sub);
                  actions.push(`added-step:${subId}:${sub}`);
                }
              }
            }
          }
        }
      }
      if (plan?.logs) {
        for (const l of plan.logs) {
          const id = addLog(l.category, l.text);
          actions.push(`added-log:${id}:${l.category}`);
        }
      }
    } catch (err) {
      console.error('AI parse error', err);
    }
  }
  // Compose messages array for chat reply.  The system tone sets
  // the assistant's personality.  In a real integration you might
  // include recent actions or summaries.
  const messages = [
    { role: 'system', content: tone.system },
    { role: 'user', content: userText },
  ];
  const reply = await callLLM(messages);
  return { reply, actions };
}