// utils/storageKeys.js
export const KEYS = {
  threads: 'you2_threads',
  focus:   'you2_focus',
  ui:      'you2_ui',
  logs:    'you2_logs',
  insights:'you2_insights'
};
